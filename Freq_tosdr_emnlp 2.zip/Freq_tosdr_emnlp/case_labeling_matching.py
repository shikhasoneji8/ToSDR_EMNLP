import pandas as pd

# Load both CSV files as DataFrames
df1 = pd.read_csv('unique_cases_with_labels.csv',  encoding='ISO-8859-1')

df2 = pd.read_csv('Freq_tosdr_emnlp/test_data_clean.csv')

print(df1.head())
# Merge the DataFrames on the 'Case' column
merged_df = pd.merge(df2, df1, on='Case', how='left')

# If you want to fill NaN values with a default value (optional)
merged_df['Label'].fillna('default_value', inplace=True)

# Save the merged DataFrame to a new CSV file
merged_df.to_csv('merged_privacy_labeling_test.csv', index=False)

# import pandas as pd

# # Load the CSV file as a DataFrame
# df = pd.read_csv('merged_privacy_labeling_train.csv')

# # Get unique 'Case' values and their corresponding 'Label'
# df_unique = df.drop_duplicates(subset=['Case'])

# # Save the unique values to a new CSV file
# df_unique.to_csv('unique_cases_with_labels.csv', index=False)

