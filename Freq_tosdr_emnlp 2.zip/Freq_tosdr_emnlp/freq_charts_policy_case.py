import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Load the data
df = pd.read_csv('Freq_tosdr_emnlp/frequency_case_policy_name_filtered_data_colab_clean.csv')  # Replace with your actual file path

# Create the plot
# plt.figure(figsize=(10, 6))
# sns.barplot(data=df, x='Cases', y='Freq', hue='Doc Type')

# Rotate x-axis labels for better readability
# plt.xticks(rotation=90)

# Show the plot
# plt.show()

# Create the plot
plt.figure(figsize=(15, 10))
bar_plot = sns.barplot(data=df, x='Cases', y='Freq', hue='Doc Type')

# Rotate x-axis labels for better readability
plt.xticks(rotation=45, ha='right')  # ha='right' will align the labels

# Adding data labels above bars
for p in bar_plot.patches:
    bar_plot.annotate(format(p.get_height(), '.1f'), 
                      (p.get_x() + p.get_width() / 2., p.get_height()), 
                      ha = 'center', va = 'center', 
                      xytext = (0, 9), 
                      textcoords = 'offset points')

# Show the plot
plt.tight_layout()
plt.show()
